<h1> Pŕactica del taller de introducción a GNU Linux</h1>

<p>Este repositorio tiene el propósito de ser clonado por las personas inscritas al taller que fue impartido 
durante las fechas 20-22/10/2025 en el Instituto Tecnológico Nacional de México campus Mérida.</p>

<br>
<p>Mucho éxito, chic@s! ^-^</p>

<div align='center'>
	<picture>
		<img alt='Linux pet' src='.assets/penguin.gif'>
	</picture>
</div>

## Instrucciones

<p>Deberán poner en práctica los comandos vistos durante el taller, al igual que algunos conceptos mencionados.</p>

<br>

<p>Si olvidan algunos parámetros para indicar alguna acción específica, recuerden hacer uso del comando man [option]
u [option] --help. Si no logran encontrar el parámetro que necesitan, pueden utilizar un navegador para buscar los usos
del comando y de esta manera conseguir el resultado requerido. Se deberán modificar los README.txt con un editor de texto
y ahí escribirán los comandos que utilizaron para lograr lo que se pide, de manera opcional pueden adjuntar una
captura de pantalla en lugar de modificar el archivo o adjuntarla y también modificar el archivo. Los ejercicios
se adjuntan mediante un zip debido a que sin esta compresión, los ejercicios no se suben correctamente a GitHub.
Recuerden que para la descompresión se utiliza el comando unzip seguido del nombre del zip.</p>

<h2><b>Queda prohibido el uso de IA</b></h2>

<p>PD: No todo lo que ven es todo lo que hay, en muchas ocasiones es necesario ver más a fondo y no quedarnos con primeras impresiones o con lo que queremos ver.</p>
