El objetivo es crear un archivo .txt que contenga como texto el nombre de la distribución que están utilizando.
En caso de que lo hayan olvidado, los comandos neofetch/fastfetch/hyfetch pueden ayudarlos con eso. En caso de
no tener instalados dichos comandos, hagan uso de su gestor de paquetes para instalarlos.

Después de crear el archivo con el nombre de su distribución, nuevamente usando el comando echo, escriban en la 
última línea el nombre de su DE (Desktop Environment)
