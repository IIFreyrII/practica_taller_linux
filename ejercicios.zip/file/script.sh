#!/bin/bash
echo "Soy un script!"
