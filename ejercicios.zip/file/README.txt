En este caso, haremos uso de file para conocer qué datos podemos obtener de un archivo/directorio y algunos
casos peculiares en ellos.

Escribe la salida de cada archivo/directorio que se encuentra presente.
