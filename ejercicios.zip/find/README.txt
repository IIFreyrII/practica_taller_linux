Encuentra todos los archivos .txt y directorios ocultos.

Escribe cuáles son
