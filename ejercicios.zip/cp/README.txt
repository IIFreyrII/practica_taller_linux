El objetivo de esta actividad es copiar el contenido de subdirectory2 que se encuentra dentro de directory1 y 
copiar su contenido en directorio1, luego se deberá copiar el directorio1 dentro de dir1.

Por imprevistos por parte del autor, creen los directorios necesarios mediante
mkdir directorio1
mkdir -m 000 dir1
