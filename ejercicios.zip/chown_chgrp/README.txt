Para esta actividad el archivo deberá ser propio de root y el directorio deberá ser parte del grupo de root
