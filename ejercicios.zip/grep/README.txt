El objetivo es hallar el .txt que contenga el texto que estamos buscando mediante el uso del comando grep en la terminal

La palabra que estamos buscando, puede estar relacionada con ITM

!Buena suerte¡
