Esta actividad consiste en utilizar el comando chmod para modificar los permisos del archivo y del directorio.
El archivo deberá tener los permisos -rwx--xrw-
El directorio deberá tener los permisos drw-r---wx
